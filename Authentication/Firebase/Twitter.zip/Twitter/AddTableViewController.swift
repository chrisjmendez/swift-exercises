//
//  AddTableViewController.swift
//  Twitter
//
//  Created by Stefan DeClerck on 7/19/15.
//  Copyright (c) 2015 Stefan DeClerck. All rights reserved.
//

import UIKit

class AddTableViewController: UITableViewController {
    
    var ref = Firebase(url: "https://twittermocker.firebaseio.com/")
    
    @IBOutlet weak var doneButton: UIBarButtonItem!
    @IBOutlet weak var postTextFIeld: UITextField!
    
    @IBAction func done(sender: AnyObject) {
        
        ref.childByAppendingPath("Posts").childByAutoId().setValue(postTextFIeld.text)
        ref.childByAppendingPath("users/\(ref.authData.uid)/post").childByAutoId().setValue(postTextFIeld.text)
        
        self.performSegueWithIdentifier("finishAddingMessage", sender: self)
        
    }
    
    func reload() {
        
        if postTextFIeld.text == "" {
            
            doneButton.enabled = false
            
        } else if postTextFIeld.text != "" {
            
            doneButton.enabled = true
            
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var timer: NSTimer = NSTimer.scheduledTimerWithTimeInterval(0.1, target: self, selector: Selector("reload"), userInfo: nil, repeats: true)
        
        self.navigationItem.hidesBackButton = true
        
    }

}

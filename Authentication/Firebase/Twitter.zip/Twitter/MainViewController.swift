//
//  MainViewController.swift
//  Twitter
//
//  Created by Stefan DeClerck on 7/19/15.
//  Copyright (c) 2015 Stefan DeClerck. All rights reserved.
//

import UIKit

class MainViewController: UITableViewController {

    var posts: [String: String] = [String: String]()
    
    var ref = Firebase(url: "https://twittermocker.firebaseio.com/")
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    
        return posts.count
    
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
    }

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        var cell: UITableViewCell = self.tableView.dequeueReusableCellWithIdentifier("cell") as! UITableViewCell
        
        var keys: Array = Array(self.posts.keys)
        cell.textLabel?.text = posts[keys[indexPath.row]] as String!
        
        return cell
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ref.observeEventType(.Value, withBlock: { snapshot in
            
            self.posts = snapshot.value.objectForKey("Posts") as! [String: String]
            println(self.posts)
            self.tableView.reloadData()
            
        })
        
    }
    
    @IBAction func logout(sender: AnyObject) {
        
        ref.unauth()
        self.performSegueWithIdentifier("logoutSegue", sender: self)
        
    }
    
}

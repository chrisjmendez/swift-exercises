@interface FirebaseServerValue : NSObject

+ (NSDictionary *) timestamp;

@end